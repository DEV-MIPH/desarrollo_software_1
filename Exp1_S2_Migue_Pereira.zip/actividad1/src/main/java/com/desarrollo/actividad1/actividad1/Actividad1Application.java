package com.desarrollo.actividad1.actividad1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Actividad1Application {

	public static void main(String[] args) {
		SpringApplication.run(Actividad1Application.class, args);
	}

}
